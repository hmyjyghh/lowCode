import Text from './Text'
import Img from './Img'
import Br from './Br'
import Div from './Div'
import A from './A'
var obj = {
  Text,
  Img,
  Br,
  Div,
  A
}

export default obj
