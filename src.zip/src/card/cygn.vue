<template>
    <div>
        我是常用功能组件
    </div>
</template>