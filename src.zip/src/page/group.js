export default [
  {
    title: '布局类',
    items: [
      { name: '一行两列', ctrlType: 'dsf.row12', isMobile: false }
    ]
  }
]
