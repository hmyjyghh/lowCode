<template>
  <div class="config">
    <ul>
      <li>
        <el-input placeholder="我是待办组件"></el-input>
      </li>
    </ul>
  </div>
</template>

<script>
// 默认输入组件
export default {
  name: 'DBList',
  data () {
    return {
    }
  }
}
</script>




