<template>
  <div class="config">
    <ul>
      <li>
        <el-input placeholder="我是Gridone布局"></el-input>
      </li>
    </ul>
  </div>
</template>

<script>
// 默认输入组件
export default {
  name: 'Gridone',
  data () {
    return {
    }
  }
}
</script>
