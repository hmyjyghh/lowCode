var Cookies = require('cookies-js');
Cookies.defaults = {
  path: '/',
  secure: true
};
export default Cookies;