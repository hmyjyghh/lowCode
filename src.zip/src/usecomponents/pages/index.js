import DsfRow12 from './row_1_2.vue'

/**
 * @module Layout
 * @description 数据组件库
 */
export {
  DsfRow12
}
